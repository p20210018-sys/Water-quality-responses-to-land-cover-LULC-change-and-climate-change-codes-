# LULC and Environmental Change Analysis – Supporting Code and Data

This repository contains the original Jupyter notebooks and the data values embedded in those notebooks. It is intended to support transparency and reproducibility of the analyses reported in the associated research manuscript.

## Repository contents

### Notebooks
- `notebooks/Mining_Original.ipynb` – notebook for mapping lead-associated ore extraction values across the countries listed in the notebook.
- `notebooks/Agriculture_Original.ipynb` – notebook for annual agricultural-land values and related change/growth visualisations (1961–2023).
- `notebooks/Forest_Cover_Original.ipynb` – notebook for forest-cover time-series analysis (1992–2022), including original and Hamed–Rao modified Mann–Kendall tests and Sen's slope visualisation.

The original notebooks are retained as uploaded. Their code and analysis steps have not been silently rewritten.

### Data
- `data/mining_embedded_data.csv` – country and lead-associated ore extraction values embedded in the Mining notebook.
- `data/agriculture_embedded_data.csv` – annual values embedded in the Agriculture notebook.
- `data/forest_cover_embedded_data.csv` – year and forest-cover values embedded in the Forest Cover notebook.

These CSV files are extracted from the notebooks; they are not independent external data downloads.

### Other files
- `requirements.txt` – Python package requirements for the analyses.
- `outputs/` – reserved for generated figures and tables.

## How to run

1. Download or clone this repository.
2. Open the required `.ipynb` notebook in Google Colab or Jupyter Notebook.
3. Install the packages listed in `requirements.txt` if they are not already available.
4. Run the notebook cells in order.
5. Some notebooks use external geographic boundary data or Google Colab-specific file download commands. Internet access may be required for those cells, and Colab-specific commands may need adjustment when using local Jupyter.

## Important data and metadata notes

- The Agriculture notebook uses the variable name `Agri_Land_Increase_%` and includes generic country wording in some figure titles. The notebook itself does not consistently identify the country or document the original data source, indicator definition, and units. These details should be confirmed and added before citing the dataset as a particular country's official agricultural-land series.
- The Mining notebook lists Algeria, Egypt, Morocco, Tunisia, and Libya and labels the values as lead-associated ore extraction in tonnes. The notebook does not provide the original source citation or reference year for these values. Add those metadata before publication if available.
- The Forest Cover notebook labels its visualisations as Algeria and specifies forest cover in square kilometres. The notebook does not include a source citation for the values; add the original data source and access date if available.
- The CSV files reproduce values embedded in the notebooks. They do not validate the accuracy, provenance, or interpretation of those values.

## Reproducibility and citation

Please cite the associated research article when reusing the code or data. For a stable, citable archive, create a GitHub release and archive that release with Zenodo to obtain a DOI. Update this README with the DOI and the final repository URL after publication.

## License

No license is assigned in this starter repository. Add a license only after confirming that you have the rights to license the code and data. A license for code does not automatically grant rights to third-party datasets.
